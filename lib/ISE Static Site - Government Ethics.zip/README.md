# ISE static site: government ethics corpus

`site/` is a complete static website generated from `ISE Data Entry.xlsx` (the two-table authoring workbook):
261 pages, one per claim, with every score computed by `score_reference.py` from the `pages` and `edges` tables.
Nothing typed is a score.

    site/index.html      belief cards, the collapsible tree, the interest registry, every page in one table
    site/p/*.html        one page per claim, linkage, importance, interest, uniqueness, equivalence, driver and media page
    site/ise.css         the one stylesheet (light and dark)
    site/data/ise.json   the two tables plus constants, the same content the SQL and XML exports carry
    site/.nojekyll       tells GitHub Pages to serve the folder as-is

## Regenerate after editing the workbook

    python3 render_site.py "ISE Data Entry.xlsx" site/

Needs `ise_tables.py`, `score_reference.py`, `build_pages.py` and `build_subpages.py` next to it (all in the
build folder delivered earlier), and openpyxl. Takes a few seconds. The last lines it prints are the internal
link check (must be 0 broken) and each belief's truth score, which should equal the workbook's Contents tab.

## Publish on GitHub Pages

Option A, the `docs/` folder on the main branch (simplest):

1. In the ideastockexchange repo, copy the contents of `site/` into a folder named `docs/`.
2. Commit and push.
3. Repo Settings, Pages, Source: "Deploy from a branch", Branch: `master` (or `main`), Folder: `/docs`. Save.
4. The site appears at https://myklob.github.io/ideastockexchange/ within a minute or two.

Option B, a `gh-pages` branch: push the contents of `site/` as the root of a branch named `gh-pages` and pick that
branch, folder `/ (root)`, in the same settings screen.

All links are relative (`p/...`, `../index.html`, `../ise.css`), so the site works from any subpath and from a
local folder opened in a browser. To point ideastockexchange.org at it later, add a `CNAME` file containing the
domain to the same folder and set the DNS records GitHub Pages documents.

## Preview inside Claude

`make_artifact.py site/ site_artifact/` produces the variant published as the Claude artifact: the same pages with the
stylesheet inlined and a body-only index. It is only for that preview; GitHub Pages takes `site/` directly.
